from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.db.models import Q
from django.http import HttpResponse
from django.utils import translation
from openpyxl import Workbook
from .models import BusinessProfile, Client, Order, Comment
from .forms import RegisterForm, ClientForm, OrderForm, CommentForm


def register_view(request):
    """Регистрация нового пользователя"""
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            BusinessProfile.objects.create(
                user=user,
                business_name=form.cleaned_data['business_name']
            )
            login(request, user)
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'crm/register.html', {'form': form})


def login_view(request):
    """Вход в систему"""
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'crm/login.html', {'form': form})


def logout_view(request):
    """Выход из системы"""
    logout(request)
    return redirect('login')


@login_required
def dashboard(request):
    """Главная страница"""
    profile = request.user.businessprofile
    clients_count = Client.objects.filter(business=profile).count()
    orders_new = Order.objects.filter(client__business=profile, status='new').count()
    orders_in_progress = Order.objects.filter(client__business=profile, status='in_progress').count()
    
    return render(request, 'crm/dashboard.html', {
        'profile': profile,
        'clients_count': clients_count,
        'orders_new': orders_new,
        'orders_in_progress': orders_in_progress,
    })


@login_required
def client_list(request):
    """Список клиентов"""
    profile = request.user.businessprofile
    clients = Client.objects.filter(business=profile)
    
    search = request.GET.get('search', '')
    if search:
        clients = clients.filter(Q(name__icontains=search) | Q(phone__icontains=search))
    
    return render(request, 'crm/client_list.html', {'clients': clients, 'search': search})


@login_required
def client_add(request):
    """Добавить клиента"""
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            client = form.save(commit=False)
            client.business = request.user.businessprofile
            client.save()
            return redirect('client_list')
    else:
        form = ClientForm()
    return render(request, 'crm/client_form.html', {'form': form, 'title': 'Добавить клиента'})


@login_required
def client_edit(request, pk):
    """Редактировать клиента"""
    client = get_object_or_404(Client, pk=pk, business=request.user.businessprofile)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect('client_list')
    else:
        form = ClientForm(instance=client)
    return render(request, 'crm/client_form.html', {'form': form, 'title': 'Редактировать клиента'})


@login_required
def client_detail(request, pk):
    """Детали клиента и его заявки"""
    client = get_object_or_404(Client, pk=pk, business=request.user.businessprofile)
    orders = client.orders.all()
    return render(request, 'crm/client_detail.html', {'client': client, 'orders': orders})


@login_required
def client_delete(request, pk):
    """Удалить клиента"""
    client = get_object_or_404(Client, pk=pk, business=request.user.businessprofile)
    if request.method == 'POST':
        client.delete()
        return redirect('client_list')
    return render(request, 'crm/confirm_delete.html', {'object': client, 'type': 'клиента'})


@login_required
def order_add(request, client_pk):
    """Добавить заявку"""
    client = get_object_or_404(Client, pk=client_pk, business=request.user.businessprofile)
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.client = client
            order.save()
            return redirect('client_detail', pk=client_pk)
    else:
        form = OrderForm()
    return render(request, 'crm/order_form.html', {'form': form, 'client': client, 'title': 'Добавить заявку'})


@login_required
def order_edit(request, pk):
    """Редактировать заявку"""
    order = get_object_or_404(Order, pk=pk, client__business=request.user.businessprofile)
    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect('order_detail', pk=pk)
    else:
        form = OrderForm(instance=order)
    return render(request, 'crm/order_form.html', {'form': form, 'client': order.client, 'title': 'Редактировать заявку'})


@login_required
def order_detail(request, pk):
    """Детали заявки с комментариями"""
    order = get_object_or_404(Order, pk=pk, client__business=request.user.businessprofile)
    comments = order.comments.all()
    
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.order = order
            comment.save()
            return redirect('order_detail', pk=pk)
    else:
        form = CommentForm()
    
    return render(request, 'crm/order_detail.html', {'order': order, 'comments': comments, 'form': form})


@login_required
def order_delete(request, pk):
    """Удалить заявку"""
    order = get_object_or_404(Order, pk=pk, client__business=request.user.businessprofile)
    client_pk = order.client.pk
    if request.method == 'POST':
        order.delete()
        return redirect('client_detail', pk=client_pk)
    return render(request, 'crm/confirm_delete.html', {'object': order, 'type': 'заявку'})


@login_required
def order_list(request):
    """Список всех заявок"""
    profile = request.user.businessprofile
    orders = Order.objects.filter(client__business=profile)
    
    status = request.GET.get('status', '')
    if status:
        orders = orders.filter(status=status)
    
    return render(request, 'crm/order_list.html', {'orders': orders, 'status': status})


@login_required
def export_clients(request):
    """Экспорт клиентов в Excel"""
    profile = request.user.businessprofile
    clients = Client.objects.filter(business=profile)
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Клиенты"
    ws.append(['Имя', 'Телефон', 'Заметки', 'Дата добавления'])
    
    for client in clients:
        ws.append([client.name, client.phone, client.notes, client.created_at.strftime('%d.%m.%Y')])
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=clients.xlsx'
    wb.save(response)
    return response


@login_required
def export_orders(request):
    """Экспорт заявок в Excel"""
    profile = request.user.businessprofile
    orders = Order.objects.filter(client__business=profile)
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Заявки"
    ws.append(['Клиент', 'Телефон', 'Услуга', 'Статус', 'Цена', 'Дата'])
    
    status_map = {'new': 'Новая', 'in_progress': 'В работе', 'done': 'Завершена'}
    
    for order in orders:
        ws.append([
            order.client.name,
            order.client.phone,
            order.service,
            status_map.get(order.status, order.status),
            float(order.price) if order.price else '',
            order.created_at.strftime('%d.%m.%Y')
        ])
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=orders.xlsx'
    wb.save(response)
    return response


@login_required
def change_language(request, lang):
    """Смена языка интерфейса"""
    if lang in ['ru', 'tk']:
        profile = request.user.businessprofile
        profile.language = lang
        profile.save()
        translation.activate(lang)
        request.session['django_language'] = lang
    return redirect(request.META.get('HTTP_REFERER', 'dashboard'))
