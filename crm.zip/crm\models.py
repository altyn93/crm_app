from django.db import models
from django.contrib.auth.models import User


class BusinessProfile(models.Model):
    """Профиль бизнеса"""
    LANGUAGE_CHOICES = [
        ('ru', 'Русский'),
        ('tk', 'Türkmen'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    business_name = models.CharField('Название бизнеса', max_length=200)
    language = models.CharField('Язык', max_length=2, choices=LANGUAGE_CHOICES, default='ru')
    
    def __str__(self):
        return self.business_name


class Client(models.Model):
    """Клиент"""
    business = models.ForeignKey(BusinessProfile, on_delete=models.CASCADE, related_name='clients')
    name = models.CharField('Имя', max_length=200)
    phone = models.CharField('Телефон', max_length=50)
    notes = models.TextField('Заметки', blank=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    
    def __str__(self):
        return f"{self.name} ({self.phone})"
    
    class Meta:
        ordering = ['-created_at']


class Order(models.Model):
    """Заявка"""
    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('in_progress', 'В работе'),
        ('done', 'Завершена'),
    ]
    
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='orders')
    service = models.CharField('Услуга', max_length=200)
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='new')
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    
    def __str__(self):
        return f"{self.service} - {self.client.name}"
    
    class Meta:
        ordering = ['-created_at']


class Comment(models.Model):
    """Комментарий к заявке"""
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField('Текст')
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    
    def __str__(self):
        return f"Комментарий к {self.order}"
    
    class Meta:
        ordering = ['created_at']
